﻿---@diagnostic disable: undefined-global
--[[
    工具模块
]]

检查任务 = checkdaily;
游戏状态 = getgamestate;
登入设置 = setlogin;
包含 = contains;
生成路径 = mkpath;
查找文件 = findfiles;
生成表 = mktable;
表洗牌 = tshuffle;
表旋转 = trotate;
表左移 = tsleft;
表右移 = tsright;
表去重 = tunique;
表排序 = tsort;
表合併 = tmerge;
表交换 = tswap;
表添加 = tadd;
表头部添加 = tpadd;
表尾弹出 = tpopback;
表头弹出 = tpopfront;
表头 = tfront;
表尾 = tback;

字符串分割 = split;

--[[
    系统模块
]]
截图 = capture;
载入模块 = require;
设置共享变量 = setglobal;
获取共享变量 = getglobal;
清空共享变量 = clearglobal;

封包 = send;
延时 = sleep;
创建日誌 = openlog;

输出 = print;

消息 = msg;
保存设置 = saveset;
读取设置 = loadset;
设置 = set;
左击 = lclick;
右击 = rclick;
双左击 = dbclick;
拖至 = dragto;

创建人物 = createch;
删除人物 = delch;
菜单 = menu;

说话 = say;
清屏 = cls;
登出 = logout;
回点 = logback;
归位 = eo;
按钮 = button;

人物改名 = chname;
宠物改名 = chpetname;
更换宠物 = chpet;

等待坐标 = waitpos;
等待地图 = waitmap;
等待宠物 = waitpet;
等待道具 = waititem;
等待组队 = waitteam;
等待对话 = waitdialog;
等待说话 = waitsay;

世界值 = WORLD;
游戏值 = GAME;

是否在线 = isonline;
是否战斗 = isbattle;
是否平时 = isnormal;
是否对话 = isdialog;

取时间 = gettime;
是否有效 = isvalid;

-- 类
对话框 = dialog;
聊天 = chat;
名片 = card;
队伍 = team;

--[[
    道具模块
]]

交换物品 = swapitem;
加工 = make;
料理 = cook;
取石币 = getstone;
存石币 = putstone;
丢石币 = doffstone;
买 = buy;
卖 = sell;
卖宠 = sellpet;
丢宠 = doffpet;
捡 = pickup;
丢弃道具 = doffitem;
使用道具 = useitem;
取道具 = getitem;
存道具 = putitem;
取宠物 = getpet;
存宠物 = putpet;
记录身上装备 = requip;
装上记录装备 = wequip;
脱装备 = uequip;
宠物装上装备 = pequip;
宠物脱装备 = upequip;

交易 = trade;

-- 类
道具 = item;

--[[
    人物模块
]]

组队 = join;
退出组队 = leave;
踢出组队 = kick;
加点 = skup;
使用精灵 = usemagic;
邮件 = mail;

-- 类
人物 = char;
技能 = skill;

--[[
    宠物模块
]]
学习 = learn;

-- 类
宠物 = pet;

--[[
    地图模块
]]

寻路 = findpath;
移动 = move;
封包移动 = w;
转移 = chmap;
下载 = download;
寻找NPC = findnpc;
方向 = dir;
坐标 = walkpos;

-- 类
地图 = map;

--[[
    战斗模块
]]

-- 类
战斗 = battle;

--[[
    常量模块
]]

总行数 = ROWCOUNT;
脚本路径 = SCRIPTDIR;
配置路径 = SETTINGDIR;
当前目录 = CURRENTDIR;
进程编号 = PID;
线程编号 = TID;
无限 = INFINITE;
最大线程 = MAXTHREAD;
最大脚色 = MAXCHAR;
最大方向 = MAXDIR;
最大道具 = MAXITEM;
最大装备 = MAXEQUIP;
最大名片 = MAXCARD;
最大精灵 = MAXMAGIC;
最大技能 = MAXSKILL;
最大宠物 = MAXPET;
最大宠物技能 = MAXPSKILL;
最大聊天 = MAXCHAT;
最大对话 = MAXDIALOG;
最大敌人 = MAXENEMY;
窗口句柄 = HWND;
游戏进程编号 = GAMEPID;
游戏窗口句柄 = GAMEHWND;
游戏进程句柄 = GAMEHANDLE;
当前索引 = INDEX;

--[[
    词法分析器模块
]]

-- 常量
当前文件 = FILE
当前函数 = FUNCTION
当前脚本路径 = CURRENTSCRIPTDIR

-- 函数
执行游戏 = rungame;
关闭游戏 = closegame;
打开窗口 = openwindow;
执行扩展 = runex;
停止执行扩展 = stoprunex;
执行文字扩展 = dostrex;
读取设置扩展 = loadsetex;

创建对话框 = dlg;
输入 = input;
格式化 = format;
到半角 = half;
到全角 = full;
到小写 = lower;
到大写 = upper;
字符串修剪 = trim;
到浮点数 = todb;
到整数 = toint;
字符串替换 = replace;
字符串查找 = find;
字符串正则 = regex;
字符串正则匹配 = rex;
字符串全局正则 = rexg;
随机数 = rnd;

表转字 = tjoin;