# Set console to use UTF-8 code page
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Enable ANSI escape sequences
$esc = [char]27

# Define ANSI color codes
$COLOR_RESET = "${esc}[0m"
$COLOR_RED = "${esc}[31m"
$COLOR_GREEN = "${esc}[32m"
$COLOR_YELLOW = "${esc}[33m"
$COLOR_BLUE = "${esc}[34m"
$COLOR_CYAN = "${esc}[36m"
$COLOR_WHITE = "${esc}[37m"

# Function to find the Qt directory
function Find-QtDirectory {
    $qtRoot = "C:\Qt"
    if (-not (Test-Path $qtRoot)) {
        Write-Host "${COLOR_RED}Qt root directory not found at C:\Qt.${COLOR_RESET}"
        exit 1
    }

    $qtDir = Get-ChildItem -Path $qtRoot -Directory -Recurse | Where-Object { $_.Name -match 'msvc\d{4}_64' } | Select-Object -First 1

    if (-not $qtDir) {
        Write-Host "${COLOR_RED}No suitable Qt directory found.${COLOR_RESET}"
        exit 1
    }

    return $qtDir.FullName
}

# Set variables for paths
$QT_DIR = Find-QtDirectory

# Get the current directory
$DLL_PATH = Get-Location

# Find the first .exe file in the current directory
$DLL_NAME = Get-ChildItem -Filter *.exe | Select-Object -First 1

# If no .exe is found, exit the script
if (-not $DLL_NAME) {
    Write-Host "${COLOR_RED}No .exe file found in the current directory.${COLOR_RESET}"
    Pause
    exit 1
}

# Define a list of directories to be removed (use ';' as separator)
$DIR_LIST = "$DLL_PATH\bearer"

# Echo the command to be executed for debugging
Write-Host "${COLOR_CYAN}`"$QT_DIR\bin\windeployqt.exe`" `"$DLL_PATH\$DLL_NAME`" --no-opengl-sw --no-translations --no-compiler-runtime${COLOR_RESET}"

# Call windeployqt with the specified options
& "$QT_DIR\bin\windeployqt.exe" "$DLL_PATH\$DLL_NAME" --no-opengl-sw --no-translations --no-compiler-runtime

# Check if the command was successful
if ($LASTEXITCODE -ne 0) {
    Write-Host "${COLOR_RED}windeployqt failed.${COLOR_RESET}"
    Pause
    exit $LASTEXITCODE
}

# Remove directories in the list
$DIR_LIST.Split(';') | ForEach-Object {
    if (Test-Path $_) {
        Write-Host "${COLOR_YELLOW}Removing directory $_...${COLOR_RESET}"
        Remove-Item -Recurse -Force $_
        if (Test-Path $_) {
            Write-Host "${COLOR_RED}Failed to remove directory $_.${COLOR_RESET}"
        } else {
            Write-Host "${COLOR_GREEN}Directory $_ removed successfully.${COLOR_RESET}"
        }
    } else {
        Write-Host "${COLOR_BLUE}Directory $_ does not exist.${COLOR_RESET}"
    }
}

Pause
exit 0
